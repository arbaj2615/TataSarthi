import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { CheckCircle2, XCircle, AlertCircle } from "lucide-react";
import { motion } from "framer-motion";

const formSchema = z.object({
  age: z.string().refine((val) => !isNaN(Number(val)) && Number(val) >= 18, {
    message: "Age must be at least 18.",
  }),
  employmentType: z.enum(["salaried", "self-employed"], {
    required_error: "Please select your employment type.",
  }),
  creditScore: z.string().refine((val) => !isNaN(Number(val)) && Number(val) >= 300 && Number(val) <= 900, {
    message: "Enter a valid credit score between 300 and 900.",
  }),
  monthlyIncome: z.string().min(1, "Monthly income is required"),
});

export default function Eligibility() {
  const [result, setResult] = useState<"eligible" | "not-eligible" | null>(null);
  const [reason, setReason] = useState<string>("");

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      age: "",
      monthlyIncome: "",
      creditScore: "",
    },
  });

  function onSubmit(values: z.infer<typeof formSchema>) {
    const age = Number(values.age);
    const score = Number(values.creditScore);
    const income = Number(values.monthlyIncome);

    // Rule Engine
    if (age < 21 || age > 60) {
      setResult("not-eligible");
      setReason("Age criteria not met. Required age is between 21 and 60 years.");
      return;
    }

    if (score < 700) {
      setResult("not-eligible");
      setReason("Credit score is below 700. We currently require a score of 700+.");
      return;
    }

    if (income < 15000) {
      setResult("not-eligible");
      setReason("Minimum monthly income requirement of ₹15,000 not met.");
      return;
    }

    setResult("eligible");
    setReason("");
  }

  return (
    <div className="container max-w-2xl mx-auto py-12 px-4">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
      >
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-bold tracking-tight mb-2">Check Your Loan Eligibility</h1>
          <p className="text-muted-foreground">
            Answer a few simple questions to see if you qualify for a TataSaarthi Personal Loan.
          </p>
        </div>

        <Card className="border-t-4 border-t-primary shadow-lg">
          <CardHeader>
            <CardTitle>Basic Details</CardTitle>
            <CardDescription>
              We don't store this data. It's only for this simulation.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                
                <FormField
                  control={form.control}
                  name="age"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Age (Years)</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. 28" type="number" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="employmentType"
                  render={({ field }) => (
                    <FormItem className="space-y-3">
                      <FormLabel>Employment Type</FormLabel>
                      <FormControl>
                        <RadioGroup
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          className="flex flex-col space-y-1"
                        >
                          <FormItem className="flex items-center space-x-3 space-y-0">
                            <FormControl>
                              <RadioGroupItem value="salaried" />
                            </FormControl>
                            <FormLabel className="font-normal">
                              Salaried
                            </FormLabel>
                          </FormItem>
                          <FormItem className="flex items-center space-x-3 space-y-0">
                            <FormControl>
                              <RadioGroupItem value="self-employed" />
                            </FormControl>
                            <FormLabel className="font-normal">
                              Self-Employed
                            </FormLabel>
                          </FormItem>
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="monthlyIncome"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Monthly Income (₹)</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. 50000" type="number" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="creditScore"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Credit Score</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. 750" type="number" {...field} />
                      </FormControl>
                      <FormDescription>
                        Typically ranges from 300 to 900.
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button type="submit" className="w-full h-12 text-lg">Check Eligibility</Button>
              </form>
            </Form>
          </CardContent>
        </Card>

        {result && (
          <motion.div 
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className={`mt-8 p-6 rounded-xl border ${result === "eligible" ? "bg-green-50 border-green-200" : "bg-red-50 border-red-200"}`}
          >
            <div className="flex items-start gap-4">
              {result === "eligible" ? (
                <CheckCircle2 className="h-8 w-8 text-green-600 shrink-0" />
              ) : (
                <XCircle className="h-8 w-8 text-red-600 shrink-0" />
              )}
              <div>
                <h3 className={`text-xl font-bold mb-2 ${result === "eligible" ? "text-green-800" : "text-red-800"}`}>
                  {result === "eligible" ? "Congratulations! You are Eligible." : "Sorry, you are not eligible."}
                </h3>
                <p className={`${result === "eligible" ? "text-green-700" : "text-red-700"}`}>
                  {result === "eligible" 
                    ? "Based on the details provided, you meet our criteria for a Personal Loan. Proceed to the Chat Assistant to apply instantly." 
                    : reason}
                </p>
                {result === "eligible" && (
                  <Button className="mt-4 bg-green-600 hover:bg-green-700 text-white" onClick={() => window.location.href = '/chat'}>
                    Apply via Chatbot
                  </Button>
                )}
              </div>
            </div>
          </motion.div>
        )}
      </motion.div>
    </div>
  );
}
